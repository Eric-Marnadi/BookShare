package com.example.ubook;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.text.InputType;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.webkit.WebView;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    //EditText username = (EditText) findViewById(R.id.editTextUsername);
    //EditText password = (EditText) findViewById(R.id.editTextPassword);


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        FloatingActionButton fab = findViewById(R.id.fab);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
    public void sendMessageLogin(Context context, View view)
    {
        final EditText emailValidate = (EditText)findViewById(R.id.username);
        TextView text = (TextView) findViewById(R.id.invalidEmail);
        TextView textTwo = (TextView) findViewById(R.id.usernamePasswordNot);
        String email = emailValidate.getText().toString().trim();

        final EditText passwordValidate = (EditText) findViewById(R.id.password);
        String password = passwordValidate.getText().toString().trim();

        String emailPattern = "[a-zA-Z0-9._-]+@[a-z]+\\.+[a-z]+";
        SharedPreferences prefs = context.getSharedPreferences("myAppPackage", 0);
        String inputtedUsername = prefs.getString("username", "");
        String inputtedPassword = prefs.getString("password", "");
        if(!email.matches(emailPattern))
        {
            text.setVisibility(View.VISIBLE);
        }
        else if(!email.equals(inputtedUsername)||!password.equals(inputtedPassword))
        {
            textTwo.setVisibility(View.VISIBLE);
        }
        else
        {
            setContentView(R.layout.activity_main);
        }
    }
    public void sendMessageLocation(View view, Bundle savedInstanceState) {
        setContentView(R.layout.activity_naviagtion);
    }
    public void sendMessageHomeScreen(View view) {
        setContentView(R.layout.activity_main);
    }
    public void sendMessageMadeAcct(View view)
    {
        final EditText passwordOne = (EditText)findViewById(R.id.editText2);
        final EditText passwordTwo = (EditText)findViewById(R.id.editText3);
        String passwordStringOne = passwordOne.getText().toString();
        String passwordStringTwo = passwordTwo.getText().toString();
        TextView text = (TextView) findViewById(R.id.PasswordMatch);
        if(passwordStringOne.equals(passwordStringTwo))
        {
            setContentView(R.layout.activity_main);
        }
        else
        {
            text.setVisibility(View.VISIBLE);
        }
    }
    public void sendMessageCreateAcct(View view){
        setContentView(R.layout.content_create_login);
    }
    public void sendMessageBackCreateLogin(View view){
        setContentView(R.layout.activity_login);
    }
    public void sendMessageLogOut(View view){
        setContentView(R.layout.activity_login);
    }
    public void setUsername(Context context, View view) {
        SharedPreferences prefs = context.getSharedPreferences("myAppPackage", 0);
        SharedPreferences.Editor editor = prefs.edit();
        final EditText savedUsername = (EditText)findViewById(R.id.editText);
        String saved = savedUsername.getText().toString();
        editor.putString("username", saved);
        editor.commit();
    }
    public void setPassword(Context context, View view) {
        SharedPreferences prefs = context.getSharedPreferences("myAppPackage", 0);
        SharedPreferences.Editor editor = prefs.edit();
        final EditText savedUsername = (EditText)findViewById(R.id.editText2);
        String saved = savedUsername.getText().toString();
        editor.putString("password", saved);
        editor.commit();
    }
}
